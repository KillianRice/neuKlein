Instruction: 

1. Make sure that MCL_FreqCounter.dll is copy and register in your PC
2. Run LABVIEW and open the project  LabView_FC.vi     
3. Run the project � incase there is an invoke error do the following:
    a. Right click on the  Invoke Node in the Front panel screen 
       and choose Select ActiveX class. 
    b. click on Browse and point to windows\system32\MCL_FreqCounter.dll
    c. select the first item and click O.K     
4. Make sure to connect some source to the Freq Counter. 
5. Program instruction:
   Sampling time - change according from 0.1 sec (less accurate) to 10 sec
   Range - either auto range or if the frequency is with in a known range for accuracy.     
6. Click stop to stop the program 
     



 

