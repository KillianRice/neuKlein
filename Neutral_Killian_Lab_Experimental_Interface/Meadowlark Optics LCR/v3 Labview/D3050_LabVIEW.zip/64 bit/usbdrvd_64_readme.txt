This version of the USBDRVD.dll is only for use with the Meadowlark Optics provided LabVIEW VIs when
used on LabVIEW 64 bit versions.  Just replace the file included with the sample VIs with this DLL.
DO NOT USE THIS FILE WHEN USING 32 bit LabVIEW, even on a 64 bit system.