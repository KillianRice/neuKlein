﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Runtime.InteropServices;


namespace MCA3Demo1
{
    public struct ACQSETTING
    {
        public int range;  // spectrum length, ADC range 
        public int prena;  // bit 0: realtime preset enabled
        // bit 1: livetime preset enabled
        // bit 2: sweep preset enabled
        // bit 3: ROI preset enabled
        // bit 5: ROI2 preset enabled
        public int mcsmode;         //  
        // bit 0: MCS 1 channel
        // bit 1: MCS 2 channel
        // mcsmode & 0x3==0: MCA mode
        // bit 2: MCA int. ADC        (MCA)
        // bit 3: sequential mode (MCA+MCS)
        // bit 4: tagged          (MCA+MCS)
        // bit 5: listmode        (MCA+MCS)
        // bit 6: Software Start      (MCS)
        // bit 7: differential mode   (MCS)
        // bit 8: Ch2 ref (diff.mode) (MCS)
        // bit 9: Autocorrelation     (MCS)
        // bit 10: enable sweep abort (MCS)
        // bit 11: save cycles    (MCS,sequential)
        // bit 12: use SCA Input  (MCS)
        // bit 13: History        (MCA,listmode) 
        // bit 14: highrate		  (MCS,listmode)
        public int roimin;  // lower ROI limit
        public int roimax;  // upper limit: roimin <= channel < roimax
        public int dummy1;
        public double eventpreset;   // ROI preset value
        public double rtpreset;      // time preset value
        public int savedata;         // bit 0: 1 if auto save after stop
        // bit 1: write listfile
        // bit 2: listfile only, no histogram
        // bit 3: write timestamps into listfile (MCA listmode only)
        public int fmt;     // format type: 0 == ASCII, 1 == binary
        public int autoinc; // 1 if auto increment filename
        public int diguse;  // Use of Dig I/O, GO Line:
        // bit 0: status dig 0..3
        // bit 1: Output digval and increment digval after stop
        // bit 2: Invert polarity
        // bit 3: Push-Pull output
        // bit 4..7:  Input pins 4..7 Trigger System 1..4
        // bit 8: GOWATCH
        // bit 9: GO High at Start
        // bit 10: GO Low at Stop
        // bit 11: Clear at triggered start
        // bit 12: Only triggered start
        public int digval;  // digval=0..255 value for samplechanger
        public int cycles;  // for sequential mode
        public int sequences;       // for repeated sequential mode
        public int mempart;         // number of active part
        public int dwelltime;       // 32 bit value for FPGA, time is (dwelltime+1)*25ns
        public int dwellunit;       // choice of units in dialog 0=ns, 1=usec, 2=msec, 3=sec 
        // bit 4: external clock, bit 5: manual channel advance
        public int syncout;         // sync out; bit 0..3 SyncOut1, 8..11 SyncOut2 
        // bit 7 Inv SyncOut1, bit 15 Inv SyncOut2
        // 0=CLK, 1=GATE/ABORT/ADV, 2=TRG/SAMPLE, 3=COUNT1, 4=COUNT2, 5=LIVE_INT,
        // 6=LIVE_EXT, 7=1kHz 8=SCA 9=ON, 10=EoBin,
        // 11=BIN_DIV, 12=STEP_CNT, 13=GO, 14=RAMP_DOWN, 15="1" 
        public int dummy2;
        public double ltpreset;     // Livetime preset value (MCA)
        public int nregions;        // number of regions
        public int caluse;          // bit 0 == 1 if calibration used, higher bits: formula
        public double swpreset;     // sweep preset value
        public int active;          // 1 for module enabled in system 1
        public int calpoints;       // number of calibration points
    }

    public struct ACQSTATUS
    {
        public int started;        	// aquisition status: 1 if running, 0 else
        public int dummy;
        public double runtime;  	// realtime in seconds
        public double totalsum;     // total events
        public double roisum;       // events within ROI
        public double totalrate;    // acquired total events per second

        public double nettosum;     // ROI sum with background subtracted
        public double sweeps;	// Livetime in seconds or sweeps for MCS mode
        public double deadtime;     // deadtime in percent
        public int maxval; 		// Maximum value in spectrum
    }
    

    class Program
    {
        // imports from DMCA3.DLL
        [DllImport("dmca3.dll", EntryPoint = "RunCmd")]
        extern static void RunCmd(int nDisplay, string Command);
        //		private static extern void RunCmd(int nDisplay, StringBuilder Command);
        [DllImport("dmca3.dll", EntryPoint = "GetStatus")]
        extern static int GetStatus(int nDevice);
        [DllImport("dmca3.dll", EntryPoint = "GetStatusData")]
        extern static int GetStatusData(ref ACQSTATUS Status, int nDevice);
        [DllImport("dmca3.dll", EntryPoint = "GetSettingData")]
        extern static int GetSettingData(ref ACQSETTING Setting, int nDisplay);
        [DllImport("dmca3.dll", EntryPoint = "LVGetCnt")]
        extern static int LVGetCnt(ref double cntp, int nDisplay);
        [DllImport("dmca3.dll", EntryPoint = "LVGetRoi")]
        extern static int LVGetRoi(ref int roip, int nDisplay);
        [DllImport("dmca3.dll", EntryPoint = "LVGetDat")]
        extern static int LVGetDat(ref int datp, int nDisplay);
        [DllImport("dmca3.dll", EntryPoint = "GetBlock")]
        extern static void GetBlock(ref int datp, int from, int to, int step, int nDisplay); 

        static void Main(string[] args)
        {
            ACQSETTING acq;
            ACQSTATUS Status;
            String command;
            acq = new ACQSETTING();
            Status = new ACQSTATUS();
            GetStatus(0);
            GetStatusData(ref Status, 0);
            PrintStatus(ref Status);
            Console.WriteLine();
            GetSettingData(ref acq, 0);
            PrintSetting(ref acq);
            help();
            while (true)
            {
                command = Console.ReadLine();
                if (run(command) == 1) break;
            }
        }

        static void PrintStatus(ref ACQSTATUS Status)
        {
            if (Status.started != 0) Console.WriteLine("ON"); else Console.WriteLine("OFF");
            Console.Write("runtime= ");
            Console.WriteLine(Status.runtime);
            Console.Write("total= ");
            Console.WriteLine(Status.totalsum);
            Console.Write("roi= ");
            Console.WriteLine(Status.roisum);
            Console.Write("totalrate= ");
            Console.WriteLine(Status.totalrate);
            Console.Write("sweeps(livetime)= ");
            Console.WriteLine(Status.sweeps);
        }

        static void PrintSetting(ref ACQSETTING acq)
        {
            Console.Write("range= ");
            Console.WriteLine(acq.range);
            Console.Write("prena= ");
            Console.WriteLine(acq.prena);
            Console.Write("mcsmode= ");
            Console.WriteLine(acq.mcsmode);
            Console.Write("roimin= ");
            Console.WriteLine(acq.roimin);
            Console.Write("roimax= ");
            Console.WriteLine(acq.roimax);
            Console.Write("eventpreset= ");
            Console.WriteLine(acq.eventpreset);
            Console.Write("rtpreset= ");
            Console.WriteLine(acq.rtpreset);
            Console.Write("savedata= ");
            Console.WriteLine(acq.savedata);
            Console.Write("fmt= ");
            Console.WriteLine(acq.fmt);
            Console.Write("autoinc= ");
            Console.WriteLine(acq.autoinc);
            Console.Write("diguse= ");
            Console.WriteLine(acq.diguse);
            Console.Write("digval= ");
            Console.WriteLine(acq.digval);
            Console.Write("cycles= ");
            Console.WriteLine(acq.cycles);
            Console.Write("mempart= ");
            Console.WriteLine(acq.mempart);
            Console.Write("dwelltime= ");
            Console.WriteLine(acq.dwelltime);
            Console.Write("dwellunit= ");
            Console.WriteLine(acq.dwellunit);
            Console.Write("syncout= ");
            Console.WriteLine(acq.syncout);
            Console.Write("ltpreset= ");
            Console.WriteLine(acq.ltpreset);
            Console.Write("nregions= ");
            Console.WriteLine(acq.nregions);
            Console.Write("caluse= ");
            Console.WriteLine(acq.caluse);
            Console.Write("swpreset= ");
            Console.WriteLine(acq.swpreset);
            Console.Write("active= ");
            Console.WriteLine(acq.active);
            Console.Write("calpoints= ");
            Console.WriteLine(acq.calpoints);
        }

        static int run(string command)
        {
            int i;
            ACQSETTING Setting;
            Setting = new ACQSETTING();
            int[] Spec = new int[30];
            if (command == "H") help();
            else if (command == "Q")
            {
                return 1;
            }
            else if (command == "S")
            {
                ACQSTATUS Status;
                Status = new ACQSTATUS();
                GetStatusData(ref Status, 0);
                PrintStatus(ref Status);
            }
            else if (command == "D")
            {
                GetSettingData(ref Setting, 0);
                for (i=0; i<30; i++)
                    GetBlock(ref Spec[i], i, i+1, 1, 0);
                PrintDat(Setting.range, ref Spec);
            }
            else
            {
                RunCmd(0, command);
            }
            return 0;
        }
        
        static void help()
        {
            Console.WriteLine("Commands:");
            Console.WriteLine("Q	Quit");
            Console.WriteLine("H	Help");
            Console.WriteLine("S    Status");
            Console.WriteLine("D    Data");
            Console.WriteLine("(... more see command language in MCDWIN help)");
            Console.WriteLine();
        }

        static void PrintDat(int range, ref int[] datp)
        {
            int i;
            Console.Write("first 30 of ");
            Console.Write(range);
            Console.WriteLine(" datapoints:");
            for (i = 0; i < 30; i++)
                Console.WriteLine(datp[i]);
        }
    }

}
