'Attribute VB_Name = "DECLMCD"
Namespace MCA3VB
    Public Class MCA3IO
        Const DLL = "dmca3.dll"



        Structure Acqstatus
            Public Started As Integer
            Public Dummy1 As Integer
            Public Realtime As Double
            Public Totalsum As Double
            Public Roisum As Double
            Public Totalrate As Double
            Public Netsum As Double
            Public Livetime As Double
            Public Deadtime As Double
            Public Maxval As Integer
            Public Dummy2 As Integer
        End Structure

        Structure Acqsetting
            Public Range As Integer
            Public Prena As Integer
            Public Mcsmode As Integer
            Public Roimin As Integer
            Public Roimax As Integer
            Public Dummy3 As Integer
            Public Roipreset As Double
            Public Rtpreset As Double
            Public SaveData As Integer
            Public Fmt As Integer
            Public Autoinc As Integer
            Public Diguse As Integer
            Public Digval As Integer
            Public Cycles As Integer
            Public Sequences As Integer
            Public Mempart As Integer
            Public Dwelltime As Integer
            Public Dwellunit As Integer
            Public Syncout As Integer
            Public Dummy4 As Integer
            Public Ltpreset As Double
            Public Nregions As Integer
            Public Caluse As Integer
            Public Swpreset As Double
            Public Active As Integer
            Public Calpoints As Integer
        End Structure

        Structure Acqdef
            Public Ndevices As Integer
            Public Ndisplays As Integer
            Public Nsystems As Integer
            Public Bremote As Integer
            Public Sys As Integer
        End Structure

        'imports from dmca3.dll

        Declare Sub StoreSettingData Lib "DMCA3.DLL" (ByRef Setting As Acqsetting, ByVal Ndisplay As Integer)
        Declare Function GetSettingData Lib "DMCA3.DLL" (ByRef Setting As Acqsetting, ByVal Ndisplay As Integer) As Integer
        Declare Function GetStatusData Lib "DMCA3.DLL" (ByRef Status As Acqstatus, ByVal Ndisplay As Integer) As Integer
        Declare Sub Start Lib "DMCA3.DLL" (ByVal Nsystem As Integer)
        Declare Sub Halt Lib "DMCA3.DLL" (ByVal Nsystem As Integer)
        Declare Sub Cont Lib "DMCA3.DLL" (ByVal Nsystem As Integer)
        Declare Sub NewSetting Lib "DMCA3.DLL" (ByVal Ndevice As Integer)
        Declare Function ServExec Lib "DMCA3.DLL" (ByVal Clwnd As Integer) As Integer
        Declare Function GetSpec Lib "DMCA3.DLL" (ByVal I As Integer, ByVal Ndisplay As Integer) As Integer
        Declare Sub SaveSetting Lib "DMCA3.DLL" ()
        Declare Function GetStatus Lib "DMCA3.DLL" (ByVal Ndevice As Integer) As Integer
        Declare Sub EraseData Lib "DMCA3.DLL" Alias "#16" (ByVal Nsystem As Integer)
        Declare Sub SaveData Lib "DMCA3.DLL" (ByVal Ndevice As Integer)
        Declare Sub GetBlock Lib "DMCA3.DLL" (ByRef Hist As Integer, ByVal Fromch As Integer, ByVal Toch As Integer, ByVal Stp As Integer, ByVal Ndisplay As Integer)
        Declare Sub StoreDefData Lib "DMCA3.DLL" (ByRef Def As Acqdef)
        Declare Function GetDefData Lib "DMCA3.DLL" (ByRef Def As Acqdef) As Integer
        Declare Sub LoadData Lib "DMCA3.DLL" (ByVal Ndevice As Integer)
        Declare Sub NewData Lib "DMCA3.DLL" ()
        Declare Sub HardwareDlg Lib "DMCA3.DLL" (ByVal Item As Integer)
        Declare Sub UnregisterClient Lib "DMCA3.DLL" ()
        Declare Sub DestroyClient Lib "DMCA3.DLL" ()
        Declare Sub RunCmd Lib "DMCA3.DLL" (ByVal Ndevice As Integer, ByRef Cmd As Byte)
        Declare Sub AddData Lib "DMCA3.DLL" (ByVal Ndevice As Integer)
        Declare Function LVGetRoi Lib "DMCA3.DLL" (ByRef Roi As Integer, ByVal Ndevice As Integer) As Integer
        Declare Function LVGetCnt Lib "DMCA3.DLL" (ByRef Cnt As Double, ByVal Ndevice As Integer) As Integer
        Declare Function LVGetStr Lib "DMCA3.DLL" (ByRef Comment As Byte, ByVal Ndevice As Integer) As Integer
        Declare Sub SubData Lib "DMCA3.DLL" (ByVal Ndevice As Integer)
        Declare Sub Smooth Lib "DMCA3.DLL" (ByVal Ndevice As Integer)
        Declare Function DigIn Lib "DMCA3.DLL" (ByVal Ndevice As Integer) As Integer
        Declare Function DigOut Lib "DMCA3.DLL" (ByVal Ndevice As Integer, ByVal Value As Integer) As Integer
        Declare Function DigInOut Lib "DMCA3.DLL" (ByVal Ndevice As Integer, ByVal Value As Integer, ByVal Enable As Integer) As Integer
        Declare Function CardSet Lib "DMCA3.DLL" (ByVal Ndevice As Integer) As Integer

    End Class

End Namespace
