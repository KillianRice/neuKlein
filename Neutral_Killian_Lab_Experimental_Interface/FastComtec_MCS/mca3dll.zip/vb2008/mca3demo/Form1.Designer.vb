﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TextMC = New System.Windows.Forms.TextBox
        Me.TextSys = New System.Windows.Forms.TextBox
        Me.CommandStart = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.CommandHalt = New System.Windows.Forms.Button
        Me.CommandContinue = New System.Windows.Forms.Button
        Me.CommandErase = New System.Windows.Forms.Button
        Me.CommandSave = New System.Windows.Forms.Button
        Me.CommandExecute = New System.Windows.Forms.Button
        Me.TextCommand = New System.Windows.Forms.TextBox
        Me.TextRespons = New System.Windows.Forms.TextBox
        Me.CommandUpdate = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.LabelStarted = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.LabelRealtime = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.LabelTotalsum = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.LabelRoisum = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.LabelTotalrate = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.LabelNetsum = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.LabelSweeps = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.LabelDeadtime = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.LabelMaxval = New System.Windows.Forms.Label
        Me.CommandGetstring = New System.Windows.Forms.Button
        Me.LabelLine0 = New System.Windows.Forms.Label
        Me.LabelLine1 = New System.Windows.Forms.Label
        Me.LabelLine2 = New System.Windows.Forms.Label
        Me.LabelLine3 = New System.Windows.Forms.Label
        Me.LabelLine4 = New System.Windows.Forms.Label
        Me.LabelLine5 = New System.Windows.Forms.Label
        Me.LabelLine6 = New System.Windows.Forms.Label
        Me.LabelLine7 = New System.Windows.Forms.Label
        Me.LabelLine8 = New System.Windows.Forms.Label
        Me.LabelLine9 = New System.Windows.Forms.Label
        Me.LabelLine10 = New System.Windows.Forms.Label
        Me.LabelLine11 = New System.Windows.Forms.Label
        Me.LabelLine12 = New System.Windows.Forms.Label
        Me.LabelLine13 = New System.Windows.Forms.Label
        Me.CommandSetting = New System.Windows.Forms.Button
        Me.Label12 = New System.Windows.Forms.Label
        Me.LabelRange = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.LabelPrena = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.LabelMcsmode = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.LabelRoimin = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.LabelRoimax = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.LabelRoipreset = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.LabelRtpreset = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.LabelSavedata = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.LabelFmt = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.LabelAutoinc = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.LabelDiguse = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.LabelDigval = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.LabelCycles = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.LabelSequences = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.LabelMempart = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.LabelDwelltime = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.LabelDwellunit = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.LabelSyncout = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.LabelLtpreset = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.LabelNregions = New System.Windows.Forms.Label
        Me.Label32 = New System.Windows.Forms.Label
        Me.LabelCaluse = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.LabelSwpreset = New System.Windows.Forms.Label
        Me.Label34 = New System.Windows.Forms.Label
        Me.LabelActive = New System.Windows.Forms.Label
        Me.Label35 = New System.Windows.Forms.Label
        Me.LabelCalpoints = New System.Windows.Forms.Label
        Me.CommandGetspec = New System.Windows.Forms.Button
        Me.TextChan = New System.Windows.Forms.TextBox
        Me.LabelData0 = New System.Windows.Forms.Label
        Me.LabelData1 = New System.Windows.Forms.Label
        Me.LabelData2 = New System.Windows.Forms.Label
        Me.LabelData3 = New System.Windows.Forms.Label
        Me.LabelData4 = New System.Windows.Forms.Label
        Me.LabelData5 = New System.Windows.Forms.Label
        Me.LabelData6 = New System.Windows.Forms.Label
        Me.LabelData7 = New System.Windows.Forms.Label
        Me.LabelData8 = New System.Windows.Forms.Label
        Me.LabelData9 = New System.Windows.Forms.Label
        Me.LabelData10 = New System.Windows.Forms.Label
        Me.LabelData11 = New System.Windows.Forms.Label
        Me.LabelData12 = New System.Windows.Forms.Label
        Me.LabelData13 = New System.Windows.Forms.Label
        Me.LabelData14 = New System.Windows.Forms.Label
        Me.LabelData15 = New System.Windows.Forms.Label
        Me.LabelData16 = New System.Windows.Forms.Label
        Me.LabelData17 = New System.Windows.Forms.Label
        Me.LabelData18 = New System.Windows.Forms.Label
        Me.LabelData19 = New System.Windows.Forms.Label
        Me.LabelData20 = New System.Windows.Forms.Label
        Me.LabelData21 = New System.Windows.Forms.Label
        Me.LabelData22 = New System.Windows.Forms.Label
        Me.LabelData23 = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'TextMC
        '
        Me.TextMC.Location = New System.Drawing.Point(88, 41)
        Me.TextMC.Name = "TextMC"
        Me.TextMC.Size = New System.Drawing.Size(48, 20)
        Me.TextMC.TabIndex = 1
        Me.TextMC.Text = "0"
        '
        'TextSys
        '
        Me.TextSys.Location = New System.Drawing.Point(88, 68)
        Me.TextSys.Name = "TextSys"
        Me.TextSys.Size = New System.Drawing.Size(48, 20)
        Me.TextSys.TabIndex = 3
        Me.TextSys.Text = "0"
        '
        'CommandStart
        '
        Me.CommandStart.Location = New System.Drawing.Point(38, 124)
        Me.CommandStart.Name = "CommandStart"
        Me.CommandStart.Size = New System.Drawing.Size(76, 24)
        Me.CommandStart.TabIndex = 4
        Me.CommandStart.Text = "&Start"
        Me.CommandStart.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(35, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(37, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "MCA#"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(34, 68)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "System#"
        '
        'CommandHalt
        '
        Me.CommandHalt.Location = New System.Drawing.Point(38, 154)
        Me.CommandHalt.Name = "CommandHalt"
        Me.CommandHalt.Size = New System.Drawing.Size(76, 24)
        Me.CommandHalt.TabIndex = 7
        Me.CommandHalt.Text = "&Halt"
        Me.CommandHalt.UseVisualStyleBackColor = True
        '
        'CommandContinue
        '
        Me.CommandContinue.Location = New System.Drawing.Point(38, 184)
        Me.CommandContinue.Name = "CommandContinue"
        Me.CommandContinue.Size = New System.Drawing.Size(76, 24)
        Me.CommandContinue.TabIndex = 8
        Me.CommandContinue.Text = "&Continue"
        Me.CommandContinue.UseVisualStyleBackColor = True
        '
        'CommandErase
        '
        Me.CommandErase.Location = New System.Drawing.Point(38, 214)
        Me.CommandErase.Name = "CommandErase"
        Me.CommandErase.Size = New System.Drawing.Size(76, 24)
        Me.CommandErase.TabIndex = 9
        Me.CommandErase.Text = "&Erase"
        Me.CommandErase.UseVisualStyleBackColor = True
        '
        'CommandSave
        '
        Me.CommandSave.Location = New System.Drawing.Point(38, 244)
        Me.CommandSave.Name = "CommandSave"
        Me.CommandSave.Size = New System.Drawing.Size(76, 24)
        Me.CommandSave.TabIndex = 10
        Me.CommandSave.Text = "S&ave"
        Me.CommandSave.UseVisualStyleBackColor = True
        '
        'CommandExecute
        '
        Me.CommandExecute.Location = New System.Drawing.Point(38, 343)
        Me.CommandExecute.Name = "CommandExecute"
        Me.CommandExecute.Size = New System.Drawing.Size(76, 24)
        Me.CommandExecute.TabIndex = 11
        Me.CommandExecute.Text = "E&xecute"
        Me.CommandExecute.UseVisualStyleBackColor = True
        '
        'TextCommand
        '
        Me.TextCommand.Location = New System.Drawing.Point(38, 373)
        Me.TextCommand.Name = "TextCommand"
        Me.TextCommand.Size = New System.Drawing.Size(192, 20)
        Me.TextCommand.TabIndex = 12
        Me.TextCommand.Text = "RUN TEST.CTL"
        '
        'TextRespons
        '
        Me.TextRespons.Location = New System.Drawing.Point(37, 399)
        Me.TextRespons.Name = "TextRespons"
        Me.TextRespons.Size = New System.Drawing.Size(192, 20)
        Me.TextRespons.TabIndex = 13
        '
        'CommandUpdate
        '
        Me.CommandUpdate.Location = New System.Drawing.Point(234, 12)
        Me.CommandUpdate.Name = "CommandUpdate"
        Me.CommandUpdate.Size = New System.Drawing.Size(139, 24)
        Me.CommandUpdate.TabIndex = 14
        Me.CommandUpdate.Text = "Update Status"
        Me.CommandUpdate.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(231, 44)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 13)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "Started:"
        '
        'LabelStarted
        '
        Me.LabelStarted.AutoSize = True
        Me.LabelStarted.Location = New System.Drawing.Point(306, 44)
        Me.LabelStarted.Name = "LabelStarted"
        Me.LabelStarted.Size = New System.Drawing.Size(67, 13)
        Me.LabelStarted.TabIndex = 16
        Me.LabelStarted.Text = "                  0"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(231, 57)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(51, 13)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "Realtime:"
        '
        'LabelRealtime
        '
        Me.LabelRealtime.AutoSize = True
        Me.LabelRealtime.Location = New System.Drawing.Point(306, 57)
        Me.LabelRealtime.Name = "LabelRealtime"
        Me.LabelRealtime.Size = New System.Drawing.Size(67, 13)
        Me.LabelRealtime.TabIndex = 18
        Me.LabelRealtime.Text = "                  0"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(231, 71)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 13)
        Me.Label5.TabIndex = 19
        Me.Label5.Text = "Totalsum:"
        '
        'LabelTotalsum
        '
        Me.LabelTotalsum.AutoSize = True
        Me.LabelTotalsum.Location = New System.Drawing.Point(306, 70)
        Me.LabelTotalsum.Name = "LabelTotalsum"
        Me.LabelTotalsum.Size = New System.Drawing.Size(67, 13)
        Me.LabelTotalsum.TabIndex = 20
        Me.LabelTotalsum.Text = "                  0"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(231, 84)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(45, 13)
        Me.Label6.TabIndex = 21
        Me.Label6.Text = "Roisum:"
        '
        'LabelRoisum
        '
        Me.LabelRoisum.AutoSize = True
        Me.LabelRoisum.Location = New System.Drawing.Point(306, 84)
        Me.LabelRoisum.Name = "LabelRoisum"
        Me.LabelRoisum.Size = New System.Drawing.Size(67, 13)
        Me.LabelRoisum.TabIndex = 22
        Me.LabelRoisum.Text = "                  0"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(231, 97)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(52, 13)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "Totalrate:"
        '
        'LabelTotalrate
        '
        Me.LabelTotalrate.AutoSize = True
        Me.LabelTotalrate.Location = New System.Drawing.Point(306, 97)
        Me.LabelTotalrate.Name = "LabelTotalrate"
        Me.LabelTotalrate.Size = New System.Drawing.Size(67, 13)
        Me.LabelTotalrate.TabIndex = 24
        Me.LabelTotalrate.Text = "                  0"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(232, 110)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(46, 13)
        Me.Label8.TabIndex = 25
        Me.Label8.Text = "Netsum:"
        '
        'LabelNetsum
        '
        Me.LabelNetsum.AutoSize = True
        Me.LabelNetsum.Location = New System.Drawing.Point(306, 110)
        Me.LabelNetsum.Name = "LabelNetsum"
        Me.LabelNetsum.Size = New System.Drawing.Size(67, 13)
        Me.LabelNetsum.TabIndex = 26
        Me.LabelNetsum.Text = "                  0"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(208, 124)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(92, 13)
        Me.Label9.TabIndex = 27
        Me.Label9.Text = "Livetime/Sweeps:"
        '
        'LabelSweeps
        '
        Me.LabelSweeps.AutoSize = True
        Me.LabelSweeps.Location = New System.Drawing.Point(306, 124)
        Me.LabelSweeps.Name = "LabelSweeps"
        Me.LabelSweeps.Size = New System.Drawing.Size(67, 13)
        Me.LabelSweeps.TabIndex = 28
        Me.LabelSweeps.Text = "                  0"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(231, 137)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(55, 13)
        Me.Label10.TabIndex = 29
        Me.Label10.Text = "Deadtime:"
        '
        'LabelDeadtime
        '
        Me.LabelDeadtime.AutoSize = True
        Me.LabelDeadtime.Location = New System.Drawing.Point(306, 137)
        Me.LabelDeadtime.Name = "LabelDeadtime"
        Me.LabelDeadtime.Size = New System.Drawing.Size(67, 13)
        Me.LabelDeadtime.TabIndex = 30
        Me.LabelDeadtime.Text = "                  0"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(231, 150)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(44, 13)
        Me.Label11.TabIndex = 31
        Me.Label11.Text = "Maxval:"
        '
        'LabelMaxval
        '
        Me.LabelMaxval.AutoSize = True
        Me.LabelMaxval.Location = New System.Drawing.Point(306, 150)
        Me.LabelMaxval.Name = "LabelMaxval"
        Me.LabelMaxval.Size = New System.Drawing.Size(67, 13)
        Me.LabelMaxval.TabIndex = 32
        Me.LabelMaxval.Text = "                  0"
        '
        'CommandGetstring
        '
        Me.CommandGetstring.Location = New System.Drawing.Point(234, 184)
        Me.CommandGetstring.Name = "CommandGetstring"
        Me.CommandGetstring.Size = New System.Drawing.Size(139, 24)
        Me.CommandGetstring.TabIndex = 33
        Me.CommandGetstring.Text = "Get Strings"
        Me.CommandGetstring.UseVisualStyleBackColor = True
        '
        'LabelLine0
        '
        Me.LabelLine0.AutoSize = True
        Me.LabelLine0.Location = New System.Drawing.Point(237, 223)
        Me.LabelLine0.Name = "LabelLine0"
        Me.LabelLine0.Size = New System.Drawing.Size(33, 13)
        Me.LabelLine0.TabIndex = 34
        Me.LabelLine0.Text = "Line0"
        '
        'LabelLine1
        '
        Me.LabelLine1.AutoSize = True
        Me.LabelLine1.Location = New System.Drawing.Point(237, 236)
        Me.LabelLine1.Name = "LabelLine1"
        Me.LabelLine1.Size = New System.Drawing.Size(33, 13)
        Me.LabelLine1.TabIndex = 35
        Me.LabelLine1.Text = "Line1"
        '
        'LabelLine2
        '
        Me.LabelLine2.AutoSize = True
        Me.LabelLine2.Location = New System.Drawing.Point(237, 249)
        Me.LabelLine2.Name = "LabelLine2"
        Me.LabelLine2.Size = New System.Drawing.Size(33, 13)
        Me.LabelLine2.TabIndex = 36
        Me.LabelLine2.Text = "Line2"
        '
        'LabelLine3
        '
        Me.LabelLine3.AutoSize = True
        Me.LabelLine3.Location = New System.Drawing.Point(237, 262)
        Me.LabelLine3.Name = "LabelLine3"
        Me.LabelLine3.Size = New System.Drawing.Size(33, 13)
        Me.LabelLine3.TabIndex = 37
        Me.LabelLine3.Text = "Line3"
        '
        'LabelLine4
        '
        Me.LabelLine4.AutoSize = True
        Me.LabelLine4.Location = New System.Drawing.Point(237, 275)
        Me.LabelLine4.Name = "LabelLine4"
        Me.LabelLine4.Size = New System.Drawing.Size(33, 13)
        Me.LabelLine4.TabIndex = 38
        Me.LabelLine4.Text = "Line4"
        '
        'LabelLine5
        '
        Me.LabelLine5.AutoSize = True
        Me.LabelLine5.Location = New System.Drawing.Point(237, 288)
        Me.LabelLine5.Name = "LabelLine5"
        Me.LabelLine5.Size = New System.Drawing.Size(33, 13)
        Me.LabelLine5.TabIndex = 39
        Me.LabelLine5.Text = "Line5"
        '
        'LabelLine6
        '
        Me.LabelLine6.AutoSize = True
        Me.LabelLine6.Location = New System.Drawing.Point(237, 301)
        Me.LabelLine6.Name = "LabelLine6"
        Me.LabelLine6.Size = New System.Drawing.Size(33, 13)
        Me.LabelLine6.TabIndex = 40
        Me.LabelLine6.Text = "Line6"
        '
        'LabelLine7
        '
        Me.LabelLine7.AutoSize = True
        Me.LabelLine7.Location = New System.Drawing.Point(237, 314)
        Me.LabelLine7.Name = "LabelLine7"
        Me.LabelLine7.Size = New System.Drawing.Size(33, 13)
        Me.LabelLine7.TabIndex = 41
        Me.LabelLine7.Text = "Line7"
        '
        'LabelLine8
        '
        Me.LabelLine8.AutoSize = True
        Me.LabelLine8.Location = New System.Drawing.Point(237, 327)
        Me.LabelLine8.Name = "LabelLine8"
        Me.LabelLine8.Size = New System.Drawing.Size(33, 13)
        Me.LabelLine8.TabIndex = 42
        Me.LabelLine8.Text = "Line8"
        '
        'LabelLine9
        '
        Me.LabelLine9.AutoSize = True
        Me.LabelLine9.Location = New System.Drawing.Point(237, 340)
        Me.LabelLine9.Name = "LabelLine9"
        Me.LabelLine9.Size = New System.Drawing.Size(33, 13)
        Me.LabelLine9.TabIndex = 43
        Me.LabelLine9.Text = "Line9"
        '
        'LabelLine10
        '
        Me.LabelLine10.AutoSize = True
        Me.LabelLine10.Location = New System.Drawing.Point(237, 353)
        Me.LabelLine10.Name = "LabelLine10"
        Me.LabelLine10.Size = New System.Drawing.Size(39, 13)
        Me.LabelLine10.TabIndex = 44
        Me.LabelLine10.Text = "Line10"
        '
        'LabelLine11
        '
        Me.LabelLine11.AutoSize = True
        Me.LabelLine11.Location = New System.Drawing.Point(237, 366)
        Me.LabelLine11.Name = "LabelLine11"
        Me.LabelLine11.Size = New System.Drawing.Size(39, 13)
        Me.LabelLine11.TabIndex = 45
        Me.LabelLine11.Text = "Line11"
        '
        'LabelLine12
        '
        Me.LabelLine12.AutoSize = True
        Me.LabelLine12.Location = New System.Drawing.Point(237, 379)
        Me.LabelLine12.Name = "LabelLine12"
        Me.LabelLine12.Size = New System.Drawing.Size(39, 13)
        Me.LabelLine12.TabIndex = 46
        Me.LabelLine12.Text = "Line12"
        '
        'LabelLine13
        '
        Me.LabelLine13.AutoSize = True
        Me.LabelLine13.Location = New System.Drawing.Point(237, 402)
        Me.LabelLine13.Name = "LabelLine13"
        Me.LabelLine13.Size = New System.Drawing.Size(49, 13)
        Me.LabelLine13.TabIndex = 47
        Me.LabelLine13.Text = "Filename"
        '
        'CommandSetting
        '
        Me.CommandSetting.Location = New System.Drawing.Point(439, 12)
        Me.CommandSetting.Name = "CommandSetting"
        Me.CommandSetting.Size = New System.Drawing.Size(139, 24)
        Me.CommandSetting.TabIndex = 48
        Me.CommandSetting.Text = "Update Setting"
        Me.CommandSetting.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(446, 44)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(42, 13)
        Me.Label12.TabIndex = 49
        Me.Label12.Text = "Range:"
        '
        'LabelRange
        '
        Me.LabelRange.AutoSize = True
        Me.LabelRange.Location = New System.Drawing.Point(521, 44)
        Me.LabelRange.Name = "LabelRange"
        Me.LabelRange.Size = New System.Drawing.Size(67, 13)
        Me.LabelRange.TabIndex = 50
        Me.LabelRange.Text = "                  0"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(446, 57)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(38, 13)
        Me.Label13.TabIndex = 51
        Me.Label13.Text = "Prena:"
        '
        'LabelPrena
        '
        Me.LabelPrena.AutoSize = True
        Me.LabelPrena.Location = New System.Drawing.Point(521, 57)
        Me.LabelPrena.Name = "LabelPrena"
        Me.LabelPrena.Size = New System.Drawing.Size(67, 13)
        Me.LabelPrena.TabIndex = 52
        Me.LabelPrena.Text = "                  0"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(446, 71)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(56, 13)
        Me.Label14.TabIndex = 53
        Me.Label14.Text = "Mcsmode:"
        '
        'LabelMcsmode
        '
        Me.LabelMcsmode.AutoSize = True
        Me.LabelMcsmode.Location = New System.Drawing.Point(521, 70)
        Me.LabelMcsmode.Name = "LabelMcsmode"
        Me.LabelMcsmode.Size = New System.Drawing.Size(67, 13)
        Me.LabelMcsmode.TabIndex = 54
        Me.LabelMcsmode.Text = "                  0"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(446, 84)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(42, 13)
        Me.Label15.TabIndex = 55
        Me.Label15.Text = "Roimin:"
        '
        'LabelRoimin
        '
        Me.LabelRoimin.AutoSize = True
        Me.LabelRoimin.Location = New System.Drawing.Point(521, 84)
        Me.LabelRoimin.Name = "LabelRoimin"
        Me.LabelRoimin.Size = New System.Drawing.Size(67, 13)
        Me.LabelRoimin.TabIndex = 56
        Me.LabelRoimin.Text = "                  0"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(446, 97)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(45, 13)
        Me.Label16.TabIndex = 57
        Me.Label16.Text = "Roimax:"
        '
        'LabelRoimax
        '
        Me.LabelRoimax.AutoSize = True
        Me.LabelRoimax.Location = New System.Drawing.Point(521, 97)
        Me.LabelRoimax.Name = "LabelRoimax"
        Me.LabelRoimax.Size = New System.Drawing.Size(67, 13)
        Me.LabelRoimax.TabIndex = 58
        Me.LabelRoimax.Text = "                  0"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(446, 110)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(55, 13)
        Me.Label17.TabIndex = 59
        Me.Label17.Text = "Roipreset:"
        '
        'LabelRoipreset
        '
        Me.LabelRoipreset.AutoSize = True
        Me.LabelRoipreset.Location = New System.Drawing.Point(521, 110)
        Me.LabelRoipreset.Name = "LabelRoipreset"
        Me.LabelRoipreset.Size = New System.Drawing.Size(67, 13)
        Me.LabelRoipreset.TabIndex = 60
        Me.LabelRoipreset.Text = "                  0"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(446, 123)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(54, 13)
        Me.Label18.TabIndex = 61
        Me.Label18.Text = "RTpreset:"
        '
        'LabelRtpreset
        '
        Me.LabelRtpreset.AutoSize = True
        Me.LabelRtpreset.Location = New System.Drawing.Point(521, 123)
        Me.LabelRtpreset.Name = "LabelRtpreset"
        Me.LabelRtpreset.Size = New System.Drawing.Size(67, 13)
        Me.LabelRtpreset.TabIndex = 62
        Me.LabelRtpreset.Text = "                  0"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(446, 137)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(56, 13)
        Me.Label19.TabIndex = 63
        Me.Label19.Text = "Savedata:"
        '
        'LabelSavedata
        '
        Me.LabelSavedata.AutoSize = True
        Me.LabelSavedata.Location = New System.Drawing.Point(521, 137)
        Me.LabelSavedata.Name = "LabelSavedata"
        Me.LabelSavedata.Size = New System.Drawing.Size(67, 13)
        Me.LabelSavedata.TabIndex = 64
        Me.LabelSavedata.Text = "                  0"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(446, 150)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(27, 13)
        Me.Label20.TabIndex = 65
        Me.Label20.Text = "Fmt:"
        '
        'LabelFmt
        '
        Me.LabelFmt.AutoSize = True
        Me.LabelFmt.Location = New System.Drawing.Point(521, 150)
        Me.LabelFmt.Name = "LabelFmt"
        Me.LabelFmt.Size = New System.Drawing.Size(67, 13)
        Me.LabelFmt.TabIndex = 66
        Me.LabelFmt.Text = "                  0"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(446, 163)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(46, 13)
        Me.Label21.TabIndex = 67
        Me.Label21.Text = "Autoinc:"
        '
        'LabelAutoinc
        '
        Me.LabelAutoinc.AutoSize = True
        Me.LabelAutoinc.Location = New System.Drawing.Point(521, 163)
        Me.LabelAutoinc.Name = "LabelAutoinc"
        Me.LabelAutoinc.Size = New System.Drawing.Size(67, 13)
        Me.LabelAutoinc.TabIndex = 68
        Me.LabelAutoinc.Text = "                  0"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(446, 176)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(43, 13)
        Me.Label22.TabIndex = 69
        Me.Label22.Text = "Diguse:"
        '
        'LabelDiguse
        '
        Me.LabelDiguse.AutoSize = True
        Me.LabelDiguse.Location = New System.Drawing.Point(521, 176)
        Me.LabelDiguse.Name = "LabelDiguse"
        Me.LabelDiguse.Size = New System.Drawing.Size(67, 13)
        Me.LabelDiguse.TabIndex = 70
        Me.LabelDiguse.Text = "                  0"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(446, 189)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(40, 13)
        Me.Label23.TabIndex = 71
        Me.Label23.Text = "Digval:"
        '
        'LabelDigval
        '
        Me.LabelDigval.AutoSize = True
        Me.LabelDigval.Location = New System.Drawing.Point(521, 189)
        Me.LabelDigval.Name = "LabelDigval"
        Me.LabelDigval.Size = New System.Drawing.Size(67, 13)
        Me.LabelDigval.TabIndex = 72
        Me.LabelDigval.Text = "                  0"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(446, 202)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(41, 13)
        Me.Label24.TabIndex = 73
        Me.Label24.Text = "Cycles:"
        '
        'LabelCycles
        '
        Me.LabelCycles.AutoSize = True
        Me.LabelCycles.Location = New System.Drawing.Point(521, 202)
        Me.LabelCycles.Name = "LabelCycles"
        Me.LabelCycles.Size = New System.Drawing.Size(67, 13)
        Me.LabelCycles.TabIndex = 74
        Me.LabelCycles.Text = "                  0"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(446, 215)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(64, 13)
        Me.Label25.TabIndex = 75
        Me.Label25.Text = "Sequences:"
        '
        'LabelSequences
        '
        Me.LabelSequences.AutoSize = True
        Me.LabelSequences.Location = New System.Drawing.Point(521, 215)
        Me.LabelSequences.Name = "LabelSequences"
        Me.LabelSequences.Size = New System.Drawing.Size(67, 13)
        Me.LabelSequences.TabIndex = 76
        Me.LabelSequences.Text = "                  0"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(446, 228)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(51, 13)
        Me.Label26.TabIndex = 77
        Me.Label26.Text = "Mempart:"
        '
        'LabelMempart
        '
        Me.LabelMempart.AutoSize = True
        Me.LabelMempart.Location = New System.Drawing.Point(521, 228)
        Me.LabelMempart.Name = "LabelMempart"
        Me.LabelMempart.Size = New System.Drawing.Size(67, 13)
        Me.LabelMempart.TabIndex = 78
        Me.LabelMempart.Text = "                  0"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(446, 241)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(55, 13)
        Me.Label27.TabIndex = 79
        Me.Label27.Text = "Dwelltime:"
        '
        'LabelDwelltime
        '
        Me.LabelDwelltime.AutoSize = True
        Me.LabelDwelltime.Location = New System.Drawing.Point(521, 241)
        Me.LabelDwelltime.Name = "LabelDwelltime"
        Me.LabelDwelltime.Size = New System.Drawing.Size(67, 13)
        Me.LabelDwelltime.TabIndex = 80
        Me.LabelDwelltime.Text = "                  0"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(446, 254)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(53, 13)
        Me.Label28.TabIndex = 81
        Me.Label28.Text = "Dwellunit:"
        '
        'LabelDwellunit
        '
        Me.LabelDwellunit.AutoSize = True
        Me.LabelDwellunit.Location = New System.Drawing.Point(521, 254)
        Me.LabelDwellunit.Name = "LabelDwellunit"
        Me.LabelDwellunit.Size = New System.Drawing.Size(67, 13)
        Me.LabelDwellunit.TabIndex = 82
        Me.LabelDwellunit.Text = "                  0"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(446, 267)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(49, 13)
        Me.Label29.TabIndex = 83
        Me.Label29.Text = "Syncout:"
        '
        'LabelSyncout
        '
        Me.LabelSyncout.AutoSize = True
        Me.LabelSyncout.Location = New System.Drawing.Point(521, 267)
        Me.LabelSyncout.Name = "LabelSyncout"
        Me.LabelSyncout.Size = New System.Drawing.Size(67, 13)
        Me.LabelSyncout.TabIndex = 84
        Me.LabelSyncout.Text = "                  0"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(446, 280)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(52, 13)
        Me.Label30.TabIndex = 85
        Me.Label30.Text = "LTpreset:"
        '
        'LabelLtpreset
        '
        Me.LabelLtpreset.AutoSize = True
        Me.LabelLtpreset.Location = New System.Drawing.Point(521, 280)
        Me.LabelLtpreset.Name = "LabelLtpreset"
        Me.LabelLtpreset.Size = New System.Drawing.Size(67, 13)
        Me.LabelLtpreset.TabIndex = 86
        Me.LabelLtpreset.Text = "                  0"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(446, 293)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(52, 13)
        Me.Label31.TabIndex = 87
        Me.Label31.Text = "Nregions:"
        '
        'LabelNregions
        '
        Me.LabelNregions.AutoSize = True
        Me.LabelNregions.Location = New System.Drawing.Point(521, 293)
        Me.LabelNregions.Name = "LabelNregions"
        Me.LabelNregions.Size = New System.Drawing.Size(67, 13)
        Me.LabelNregions.TabIndex = 88
        Me.LabelNregions.Text = "                  0"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(446, 306)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(42, 13)
        Me.Label32.TabIndex = 89
        Me.Label32.Text = "Caluse:"
        '
        'LabelCaluse
        '
        Me.LabelCaluse.AutoSize = True
        Me.LabelCaluse.Location = New System.Drawing.Point(521, 306)
        Me.LabelCaluse.Name = "LabelCaluse"
        Me.LabelCaluse.Size = New System.Drawing.Size(67, 13)
        Me.LabelCaluse.TabIndex = 90
        Me.LabelCaluse.Text = "                  0"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(446, 319)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(54, 13)
        Me.Label33.TabIndex = 91
        Me.Label33.Text = "Swpreset:"
        '
        'LabelSwpreset
        '
        Me.LabelSwpreset.AutoSize = True
        Me.LabelSwpreset.Location = New System.Drawing.Point(521, 319)
        Me.LabelSwpreset.Name = "LabelSwpreset"
        Me.LabelSwpreset.Size = New System.Drawing.Size(67, 13)
        Me.LabelSwpreset.TabIndex = 92
        Me.LabelSwpreset.Text = "                  0"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(446, 332)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(40, 13)
        Me.Label34.TabIndex = 93
        Me.Label34.Text = "Active:"
        '
        'LabelActive
        '
        Me.LabelActive.AutoSize = True
        Me.LabelActive.Location = New System.Drawing.Point(521, 332)
        Me.LabelActive.Name = "LabelActive"
        Me.LabelActive.Size = New System.Drawing.Size(67, 13)
        Me.LabelActive.TabIndex = 94
        Me.LabelActive.Text = "                  0"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(446, 345)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(53, 13)
        Me.Label35.TabIndex = 95
        Me.Label35.Text = "Calpoints:"
        '
        'LabelCalpoints
        '
        Me.LabelCalpoints.AutoSize = True
        Me.LabelCalpoints.Location = New System.Drawing.Point(521, 345)
        Me.LabelCalpoints.Name = "LabelCalpoints"
        Me.LabelCalpoints.Size = New System.Drawing.Size(67, 13)
        Me.LabelCalpoints.TabIndex = 96
        Me.LabelCalpoints.Text = "                  0"
        '
        'CommandGetspec
        '
        Me.CommandGetspec.Location = New System.Drawing.Point(601, 12)
        Me.CommandGetspec.Name = "CommandGetspec"
        Me.CommandGetspec.Size = New System.Drawing.Size(139, 24)
        Me.CommandGetspec.TabIndex = 97
        Me.CommandGetspec.Text = "Get Spectrum"
        Me.CommandGetspec.UseVisualStyleBackColor = True
        '
        'TextChan
        '
        Me.TextChan.Location = New System.Drawing.Point(601, 41)
        Me.TextChan.Name = "TextChan"
        Me.TextChan.Size = New System.Drawing.Size(48, 20)
        Me.TextChan.TabIndex = 98
        Me.TextChan.Text = "0"
        '
        'LabelData0
        '
        Me.LabelData0.AutoSize = True
        Me.LabelData0.Location = New System.Drawing.Point(673, 44)
        Me.LabelData0.Name = "LabelData0"
        Me.LabelData0.Size = New System.Drawing.Size(67, 13)
        Me.LabelData0.TabIndex = 99
        Me.LabelData0.Text = "                  0"
        '
        'LabelData1
        '
        Me.LabelData1.AutoSize = True
        Me.LabelData1.Location = New System.Drawing.Point(673, 57)
        Me.LabelData1.Name = "LabelData1"
        Me.LabelData1.Size = New System.Drawing.Size(67, 13)
        Me.LabelData1.TabIndex = 100
        Me.LabelData1.Text = "                  0"
        '
        'LabelData2
        '
        Me.LabelData2.AutoSize = True
        Me.LabelData2.Location = New System.Drawing.Point(673, 71)
        Me.LabelData2.Name = "LabelData2"
        Me.LabelData2.Size = New System.Drawing.Size(67, 13)
        Me.LabelData2.TabIndex = 101
        Me.LabelData2.Text = "                  0"
        '
        'LabelData3
        '
        Me.LabelData3.AutoSize = True
        Me.LabelData3.Location = New System.Drawing.Point(673, 84)
        Me.LabelData3.Name = "LabelData3"
        Me.LabelData3.Size = New System.Drawing.Size(67, 13)
        Me.LabelData3.TabIndex = 102
        Me.LabelData3.Text = "                  0"
        '
        'LabelData4
        '
        Me.LabelData4.AutoSize = True
        Me.LabelData4.Location = New System.Drawing.Point(673, 97)
        Me.LabelData4.Name = "LabelData4"
        Me.LabelData4.Size = New System.Drawing.Size(67, 13)
        Me.LabelData4.TabIndex = 103
        Me.LabelData4.Text = "                  0"
        '
        'LabelData5
        '
        Me.LabelData5.AutoSize = True
        Me.LabelData5.Location = New System.Drawing.Point(673, 110)
        Me.LabelData5.Name = "LabelData5"
        Me.LabelData5.Size = New System.Drawing.Size(67, 13)
        Me.LabelData5.TabIndex = 104
        Me.LabelData5.Text = "                  0"
        '
        'LabelData6
        '
        Me.LabelData6.AutoSize = True
        Me.LabelData6.Location = New System.Drawing.Point(673, 124)
        Me.LabelData6.Name = "LabelData6"
        Me.LabelData6.Size = New System.Drawing.Size(67, 13)
        Me.LabelData6.TabIndex = 105
        Me.LabelData6.Text = "                  0"
        '
        'LabelData7
        '
        Me.LabelData7.AutoSize = True
        Me.LabelData7.Location = New System.Drawing.Point(673, 137)
        Me.LabelData7.Name = "LabelData7"
        Me.LabelData7.Size = New System.Drawing.Size(67, 13)
        Me.LabelData7.TabIndex = 106
        Me.LabelData7.Text = "                  0"
        '
        'LabelData8
        '
        Me.LabelData8.AutoSize = True
        Me.LabelData8.Location = New System.Drawing.Point(673, 150)
        Me.LabelData8.Name = "LabelData8"
        Me.LabelData8.Size = New System.Drawing.Size(67, 13)
        Me.LabelData8.TabIndex = 107
        Me.LabelData8.Text = "                  0"
        '
        'LabelData9
        '
        Me.LabelData9.AutoSize = True
        Me.LabelData9.Location = New System.Drawing.Point(673, 163)
        Me.LabelData9.Name = "LabelData9"
        Me.LabelData9.Size = New System.Drawing.Size(67, 13)
        Me.LabelData9.TabIndex = 108
        Me.LabelData9.Text = "                  0"
        '
        'LabelData10
        '
        Me.LabelData10.AutoSize = True
        Me.LabelData10.Location = New System.Drawing.Point(673, 176)
        Me.LabelData10.Name = "LabelData10"
        Me.LabelData10.Size = New System.Drawing.Size(67, 13)
        Me.LabelData10.TabIndex = 109
        Me.LabelData10.Text = "                  0"
        '
        'LabelData11
        '
        Me.LabelData11.AutoSize = True
        Me.LabelData11.Location = New System.Drawing.Point(673, 189)
        Me.LabelData11.Name = "LabelData11"
        Me.LabelData11.Size = New System.Drawing.Size(67, 13)
        Me.LabelData11.TabIndex = 110
        Me.LabelData11.Text = "                  0"
        '
        'LabelData12
        '
        Me.LabelData12.AutoSize = True
        Me.LabelData12.Location = New System.Drawing.Point(673, 202)
        Me.LabelData12.Name = "LabelData12"
        Me.LabelData12.Size = New System.Drawing.Size(67, 13)
        Me.LabelData12.TabIndex = 111
        Me.LabelData12.Text = "                  0"
        '
        'LabelData13
        '
        Me.LabelData13.AutoSize = True
        Me.LabelData13.Location = New System.Drawing.Point(673, 215)
        Me.LabelData13.Name = "LabelData13"
        Me.LabelData13.Size = New System.Drawing.Size(67, 13)
        Me.LabelData13.TabIndex = 112
        Me.LabelData13.Text = "                  0"
        '
        'LabelData14
        '
        Me.LabelData14.AutoSize = True
        Me.LabelData14.Location = New System.Drawing.Point(673, 228)
        Me.LabelData14.Name = "LabelData14"
        Me.LabelData14.Size = New System.Drawing.Size(67, 13)
        Me.LabelData14.TabIndex = 113
        Me.LabelData14.Text = "                  0"
        '
        'LabelData15
        '
        Me.LabelData15.AutoSize = True
        Me.LabelData15.Location = New System.Drawing.Point(673, 241)
        Me.LabelData15.Name = "LabelData15"
        Me.LabelData15.Size = New System.Drawing.Size(67, 13)
        Me.LabelData15.TabIndex = 114
        Me.LabelData15.Text = "                  0"
        '
        'LabelData16
        '
        Me.LabelData16.AutoSize = True
        Me.LabelData16.Location = New System.Drawing.Point(673, 254)
        Me.LabelData16.Name = "LabelData16"
        Me.LabelData16.Size = New System.Drawing.Size(67, 13)
        Me.LabelData16.TabIndex = 115
        Me.LabelData16.Text = "                  0"
        '
        'LabelData17
        '
        Me.LabelData17.AutoSize = True
        Me.LabelData17.Location = New System.Drawing.Point(673, 267)
        Me.LabelData17.Name = "LabelData17"
        Me.LabelData17.Size = New System.Drawing.Size(67, 13)
        Me.LabelData17.TabIndex = 116
        Me.LabelData17.Text = "                  0"
        '
        'LabelData18
        '
        Me.LabelData18.AutoSize = True
        Me.LabelData18.Location = New System.Drawing.Point(673, 280)
        Me.LabelData18.Name = "LabelData18"
        Me.LabelData18.Size = New System.Drawing.Size(67, 13)
        Me.LabelData18.TabIndex = 117
        Me.LabelData18.Text = "                  0"
        '
        'LabelData19
        '
        Me.LabelData19.AutoSize = True
        Me.LabelData19.Location = New System.Drawing.Point(673, 293)
        Me.LabelData19.Name = "LabelData19"
        Me.LabelData19.Size = New System.Drawing.Size(67, 13)
        Me.LabelData19.TabIndex = 118
        Me.LabelData19.Text = "                  0"
        '
        'LabelData20
        '
        Me.LabelData20.AutoSize = True
        Me.LabelData20.Location = New System.Drawing.Point(673, 306)
        Me.LabelData20.Name = "LabelData20"
        Me.LabelData20.Size = New System.Drawing.Size(67, 13)
        Me.LabelData20.TabIndex = 119
        Me.LabelData20.Text = "                  0"
        '
        'LabelData21
        '
        Me.LabelData21.AutoSize = True
        Me.LabelData21.Location = New System.Drawing.Point(673, 319)
        Me.LabelData21.Name = "LabelData21"
        Me.LabelData21.Size = New System.Drawing.Size(67, 13)
        Me.LabelData21.TabIndex = 120
        Me.LabelData21.Text = "                  0"
        '
        'LabelData22
        '
        Me.LabelData22.AutoSize = True
        Me.LabelData22.Location = New System.Drawing.Point(673, 332)
        Me.LabelData22.Name = "LabelData22"
        Me.LabelData22.Size = New System.Drawing.Size(67, 13)
        Me.LabelData22.TabIndex = 121
        Me.LabelData22.Text = "                  0"
        '
        'LabelData23
        '
        Me.LabelData23.AutoSize = True
        Me.LabelData23.Location = New System.Drawing.Point(673, 345)
        Me.LabelData23.Name = "LabelData23"
        Me.LabelData23.Size = New System.Drawing.Size(67, 13)
        Me.LabelData23.TabIndex = 122
        Me.LabelData23.Text = "                  0"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(802, 573)
        Me.Controls.Add(Me.LabelData23)
        Me.Controls.Add(Me.LabelData22)
        Me.Controls.Add(Me.LabelData21)
        Me.Controls.Add(Me.LabelData20)
        Me.Controls.Add(Me.LabelData19)
        Me.Controls.Add(Me.LabelData18)
        Me.Controls.Add(Me.LabelData17)
        Me.Controls.Add(Me.LabelData16)
        Me.Controls.Add(Me.LabelData15)
        Me.Controls.Add(Me.LabelData14)
        Me.Controls.Add(Me.LabelData13)
        Me.Controls.Add(Me.LabelData12)
        Me.Controls.Add(Me.LabelData11)
        Me.Controls.Add(Me.LabelData10)
        Me.Controls.Add(Me.LabelData9)
        Me.Controls.Add(Me.LabelData8)
        Me.Controls.Add(Me.LabelData7)
        Me.Controls.Add(Me.LabelData6)
        Me.Controls.Add(Me.LabelData5)
        Me.Controls.Add(Me.LabelData4)
        Me.Controls.Add(Me.LabelData3)
        Me.Controls.Add(Me.LabelData2)
        Me.Controls.Add(Me.LabelData1)
        Me.Controls.Add(Me.LabelData0)
        Me.Controls.Add(Me.TextChan)
        Me.Controls.Add(Me.CommandGetspec)
        Me.Controls.Add(Me.LabelCalpoints)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.LabelActive)
        Me.Controls.Add(Me.Label34)
        Me.Controls.Add(Me.LabelSwpreset)
        Me.Controls.Add(Me.Label33)
        Me.Controls.Add(Me.LabelCaluse)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.LabelNregions)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.LabelLtpreset)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.LabelSyncout)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.LabelDwellunit)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.LabelDwelltime)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.LabelMempart)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.LabelSequences)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.LabelCycles)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.LabelDigval)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.LabelDiguse)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.LabelAutoinc)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.LabelFmt)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.LabelSavedata)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.LabelRtpreset)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.LabelRoipreset)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.LabelRoimax)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.LabelRoimin)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.LabelMcsmode)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.LabelPrena)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.LabelRange)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.CommandSetting)
        Me.Controls.Add(Me.LabelLine13)
        Me.Controls.Add(Me.LabelLine12)
        Me.Controls.Add(Me.LabelLine11)
        Me.Controls.Add(Me.LabelLine10)
        Me.Controls.Add(Me.LabelLine9)
        Me.Controls.Add(Me.LabelLine8)
        Me.Controls.Add(Me.LabelLine7)
        Me.Controls.Add(Me.LabelLine6)
        Me.Controls.Add(Me.LabelLine5)
        Me.Controls.Add(Me.LabelLine4)
        Me.Controls.Add(Me.LabelLine3)
        Me.Controls.Add(Me.LabelLine2)
        Me.Controls.Add(Me.LabelLine1)
        Me.Controls.Add(Me.LabelLine0)
        Me.Controls.Add(Me.CommandGetstring)
        Me.Controls.Add(Me.LabelMaxval)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.LabelDeadtime)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.LabelSweeps)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.LabelNetsum)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.LabelTotalrate)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.LabelRoisum)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.LabelTotalsum)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.LabelRealtime)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.LabelStarted)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.CommandUpdate)
        Me.Controls.Add(Me.TextRespons)
        Me.Controls.Add(Me.TextCommand)
        Me.Controls.Add(Me.CommandExecute)
        Me.Controls.Add(Me.CommandSave)
        Me.Controls.Add(Me.CommandErase)
        Me.Controls.Add(Me.CommandContinue)
        Me.Controls.Add(Me.CommandHalt)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CommandStart)
        Me.Controls.Add(Me.TextSys)
        Me.Controls.Add(Me.TextMC)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "MCA3 Demo"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TextMC As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents CommandHalt As System.Windows.Forms.Button
    Friend WithEvents TextSys As System.Windows.Forms.TextBox
    Friend WithEvents CommandStart As System.Windows.Forms.Button
    Friend WithEvents CommandContinue As System.Windows.Forms.Button
    Friend WithEvents CommandErase As System.Windows.Forms.Button
    Friend WithEvents CommandSave As System.Windows.Forms.Button
    Friend WithEvents CommandExecute As System.Windows.Forms.Button
    Friend WithEvents TextCommand As System.Windows.Forms.TextBox
    Friend WithEvents TextRespons As System.Windows.Forms.TextBox
    Friend WithEvents CommandUpdate As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents LabelStarted As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents LabelRealtime As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents LabelTotalsum As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents LabelRoisum As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents LabelTotalrate As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents LabelNetsum As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents LabelSweeps As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents LabelDeadtime As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents LabelMaxval As System.Windows.Forms.Label
    Friend WithEvents CommandGetstring As System.Windows.Forms.Button
    Friend WithEvents LabelLine0 As System.Windows.Forms.Label
    Friend WithEvents LabelLine1 As System.Windows.Forms.Label
    Friend WithEvents LabelLine2 As System.Windows.Forms.Label
    Friend WithEvents LabelLine3 As System.Windows.Forms.Label
    Friend WithEvents LabelLine4 As System.Windows.Forms.Label
    Friend WithEvents LabelLine5 As System.Windows.Forms.Label
    Friend WithEvents LabelLine6 As System.Windows.Forms.Label
    Friend WithEvents LabelLine7 As System.Windows.Forms.Label
    Friend WithEvents LabelLine8 As System.Windows.Forms.Label
    Friend WithEvents LabelLine9 As System.Windows.Forms.Label
    Friend WithEvents LabelLine10 As System.Windows.Forms.Label
    Friend WithEvents LabelLine11 As System.Windows.Forms.Label
    Friend WithEvents LabelLine12 As System.Windows.Forms.Label
    Friend WithEvents LabelLine13 As System.Windows.Forms.Label
    Friend WithEvents CommandSetting As System.Windows.Forms.Button
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents LabelRange As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents LabelPrena As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents LabelMcsmode As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents LabelRoimin As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents LabelRoimax As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents LabelRoipreset As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents LabelRtpreset As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents LabelSavedata As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents LabelFmt As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents LabelAutoinc As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents LabelDiguse As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents LabelDigval As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents LabelCycles As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents LabelSequences As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents LabelMempart As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents LabelDwelltime As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents LabelDwellunit As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents LabelSyncout As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents LabelLtpreset As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents LabelNregions As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents LabelCaluse As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents LabelSwpreset As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents LabelActive As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents LabelCalpoints As System.Windows.Forms.Label
    Friend WithEvents CommandGetspec As System.Windows.Forms.Button
    Friend WithEvents TextChan As System.Windows.Forms.TextBox
    Friend WithEvents LabelData0 As System.Windows.Forms.Label
    Friend WithEvents LabelData1 As System.Windows.Forms.Label
    Friend WithEvents LabelData2 As System.Windows.Forms.Label
    Friend WithEvents LabelData3 As System.Windows.Forms.Label
    Friend WithEvents LabelData4 As System.Windows.Forms.Label
    Friend WithEvents LabelData5 As System.Windows.Forms.Label
    Friend WithEvents LabelData6 As System.Windows.Forms.Label
    Friend WithEvents LabelData7 As System.Windows.Forms.Label
    Friend WithEvents LabelData8 As System.Windows.Forms.Label
    Friend WithEvents LabelData9 As System.Windows.Forms.Label
    Friend WithEvents LabelData10 As System.Windows.Forms.Label
    Friend WithEvents LabelData11 As System.Windows.Forms.Label
    Friend WithEvents LabelData12 As System.Windows.Forms.Label
    Friend WithEvents LabelData13 As System.Windows.Forms.Label
    Friend WithEvents LabelData14 As System.Windows.Forms.Label
    Friend WithEvents LabelData15 As System.Windows.Forms.Label
    Friend WithEvents LabelData16 As System.Windows.Forms.Label
    Friend WithEvents LabelData17 As System.Windows.Forms.Label
    Friend WithEvents LabelData18 As System.Windows.Forms.Label
    Friend WithEvents LabelData19 As System.Windows.Forms.Label
    Friend WithEvents LabelData20 As System.Windows.Forms.Label
    Friend WithEvents LabelData21 As System.Windows.Forms.Label
    Friend WithEvents LabelData22 As System.Windows.Forms.Label
    Friend WithEvents LabelData23 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
End Class
