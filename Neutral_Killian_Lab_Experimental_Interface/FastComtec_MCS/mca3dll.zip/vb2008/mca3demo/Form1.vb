﻿Imports System
Imports System.Runtime.InteropServices
Imports mca3demo.MCA3VB
Public Class Form1
    Dim Sysno As Integer
    Dim Status As mca3demo.MCA3VB.MCA3IO.Acqstatus
    Dim Setting As mca3demo.MCA3VB.MCA3IO.Acqsetting
    Dim OldStarted As Integer
    Dim Mcano As Integer
    Dim Chan As Integer
    Dim Hist(24) As Integer
    Dim Toggle As Integer
    Dim Ret As Integer
    Dim ccc(2048) As Char
    Dim bcc(256) As Char


    Private Sub CommandStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandStart.Click
        Sysno = Val(TextSys.Text)
        Call mca3demo.MCA3VB.MCA3IO.Start(Sysno)
    End Sub

    Private Sub CommandHalt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandHalt.Click
        Sysno = Val(TextSys.Text)
        Call mca3demo.MCA3VB.MCA3IO.Halt(Sysno)
    End Sub

    Private Sub UpdateStatus()
        LabelStarted.Text = Status.Started
        LabelRealtime.Text = Status.Realtime
        LabelTotalsum.Text = Status.Totalsum
        LabelRoisum.Text = Status.Roisum
        LabelTotalrate.Text = Format$(Status.Totalrate, "######0.0#")
        LabelNetsum.Text = Status.Netsum
        LabelSweeps.Text = Status.Livetime
        LabelDeadtime.Text = Format$(Status.Deadtime, "######0.0#")
        LabelMaxval.Text = Status.Maxval
    End Sub

    Private Sub UpdateSetting()
        LabelRange.Text = Setting.Range
        LabelPrena.Text = Setting.Prena
        LabelMcsmode.Text = Setting.Mcsmode
        LabelRoimin.Text = Setting.Roimin
        LabelRoimax.Text = Setting.Roimax
        LabelRoipreset.Text = Setting.Roipreset
        LabelRtpreset.Text = Setting.Rtpreset
        LabelSavedata.Text = Setting.SaveData
        LabelFmt.Text = Setting.Fmt
        LabelAutoinc.Text = Setting.Autoinc
        LabelDiguse.Text = Setting.Diguse
        LabelDigval.Text = Setting.Digval
        LabelCycles.Text = Setting.Cycles
        LabelSequences.Text = Setting.Sequences
        LabelMempart.Text = Setting.Mempart
        LabelDwelltime.Text = Setting.Dwelltime
        LabelDwellunit.Text = Setting.Dwellunit
        LabelSyncout.Text = Setting.Syncout
        LabelLtpreset.Text = Setting.Ltpreset
        LabelNregions.Text = Setting.Nregions
        LabelCaluse.Text = Setting.Caluse
        LabelSwpreset.Text = Setting.Swpreset
        LabelActive.Text = Setting.Active
        LabelCalpoints.Text = Setting.Calpoints
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        OldStarted = 0
        Mcano = 0
        Sysno = 0
        Chan = 0
        Ret = mca3demo.MCA3VB.MCA3IO.ServExec(0)
        Ret = mca3demo.MCA3VB.MCA3IO.GetStatus(0)
        Ret = mca3demo.MCA3VB.MCA3IO.GetStatusData(Status, 0)
        Call UpdateStatus()
        Ret = mca3demo.MCA3VB.MCA3IO.GetSettingData(Setting, 0)
        Call UpdateSetting()
    End Sub

    Private Sub CommandContinue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandContinue.Click
        Sysno = Val(TextSys.Text)
        Call mca3demo.MCA3VB.MCA3IO.Cont(Sysno)
    End Sub

    Private Sub CommandErase_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandErase.Click
        Sysno = Val(TextSys.Text)
        Call mca3demo.MCA3VB.MCA3IO.EraseData(Sysno)
    End Sub

    Private Sub CommandSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandSave.Click
        Mcano = Val(TextMC.Text)
        Call mca3demo.MCA3VB.MCA3IO.SaveData(Mcano)
    End Sub

    Private Sub CommandExecute_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandExecute.Click
        Dim cmd As String
        Dim c(256) As Byte
        Dim ccs As Short
        cmd = "                                                                                                                     "
        Mid$(cmd, 1) = TextCommand.Text
        bcc = cmd
        For index As Integer = 0 To 100
            ccs = Asc(bcc(index))
            c(index) = ccs
        Next

        Call mca3demo.MCA3VB.MCA3IO.RunCmd(0, c(0))
        For index As Integer = 0 To 100
            ccs = c(index)
            bcc(index) = Chr(ccs)
        Next
        cmd = bcc

        TextRespons.Text = cmd
        Mcano = Val(TextMC.Text)
        Ret = mca3demo.MCA3VB.MCA3IO.GetStatus(Mcano)
        Ret = mca3demo.MCA3VB.MCA3IO.GetStatusData(Status, Mcano)
        Call UpdateStatus()
    End Sub

    Private Sub CommandUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandUpdate.Click
        Mcano = Val(TextMC.Text)
        'Ret = mca3demo.MCA3VB.MCA3IO.GetStatus(Mcano)
        If mca3demo.MCA3VB.MCA3IO.GetStatusData(Status, Mcano) = 1 Then
            Call UpdateStatus()
        End If
    End Sub

    Private Sub CommandGetstring_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandGetstring.Click
        Dim b As String
        Dim c(2048) As Byte
        Dim ccs As Short
        b = "                                                                                                                     "
        Mcano = Val(TextMC.Text)
        Ret = mca3demo.MCA3VB.MCA3IO.LVGetStr(c(0), Mcano)

        For index As Integer = 0 To 2047
            ccs = c(index)
            ccc(index) = Chr(ccs)
        Next
        b = ccc
        LabelLine0.Text = Mid$(b, 1, 60)
        LabelLine1.Text = Mid$(b, 61, 60)
        LabelLine2.Text = Mid$(b, 121, 60)
        LabelLine3.Text = Mid$(b, 181, 60)
        LabelLine4.Text = Mid$(b, 241, 60)
        LabelLine5.Text = Mid$(b, 301, 60)
        LabelLine6.Text = Mid$(b, 361, 60)
        LabelLine7.Text = Mid$(b, 421, 60)
        LabelLine8.Text = Mid$(b, 481, 60)
        LabelLine9.Text = Mid$(b, 541, 60)
        LabelLine10.Text = Mid$(b, 601, 60)
        LabelLine11.Text = Mid$(b, 881, 60)
        LabelLine12.Text = Mid$(b, 961, 60)
        LabelLine13.Text = Mid$(b, 661, 100)
    End Sub

    Private Sub CommandSetting_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandSetting.Click
        Mcano = Val(TextMC.Text)
        If mca3demo.MCA3VB.MCA3IO.GetSettingData(Setting, Mcano) = 1 Then
            Call UpdateSetting()
        End If
    End Sub

    Private Sub CommandGetspec_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandGetspec.Click
        Mcano = Val(TextMC.Text)
        Chan = Val(TextChan.Text)
        Call mca3demo.MCA3VB.MCA3IO.GetBlock(Hist(0), Chan, Chan + 24, 1, Mcano)
        LabelData0.Text = Hist(0)
        LabelData1.Text = Hist(1)
        LabelData2.Text = Hist(2)
        LabelData3.Text = Hist(3)
        LabelData4.Text = Hist(4)
        LabelData5.Text = Hist(5)
        LabelData6.Text = Hist(6)
        LabelData7.Text = Hist(7)
        LabelData8.Text = Hist(8)
        LabelData9.Text = Hist(9)
        LabelData10.Text = Hist(10)
        LabelData11.Text = Hist(11)
        LabelData12.Text = Hist(12)
        LabelData13.Text = Hist(13)
        LabelData14.Text = Hist(14)
        LabelData15.Text = Hist(15)
        LabelData16.Text = Hist(16)
        LabelData17.Text = Hist(17)
        LabelData18.Text = Hist(18)
        LabelData19.Text = Hist(19)
        LabelData20.Text = Hist(20)
        LabelData21.Text = Hist(21)
        LabelData22.Text = Hist(22)
        LabelData23.Text = Hist(23)
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Mcano = Val(TextMC.Text)
        If Mcano > 3 Then
            Mcano = 3
        End If
        If Mcano < 0 Then
            Mcano = 0
        End If
        Ret = mca3demo.MCA3VB.MCA3IO.GetStatus(Mcano)
        If mca3demo.MCA3VB.MCA3IO.GetStatusData(Status, Mcano) = 1 Then
            If Status.Started = 1 Or OldStarted = 1 Then
                Call UpdateStatus()
                Toggle = Not Toggle
                OldStarted = Status.Started
            End If
        End If
    End Sub
End Class
